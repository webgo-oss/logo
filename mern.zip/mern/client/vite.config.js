import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// In development, only API requests are forwarded to Express.
// Logo preview images live in client/public/logos/preview and are served by Vite itself.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:5000',
    },
  },
});
